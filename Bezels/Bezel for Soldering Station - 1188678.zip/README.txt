Bezel for Soldering Station by pepperm on Thingiverse: https://www.thingiverse.com/thing:1188678

Summary:
For the Soldering Station Thing 1064001.A bezel to accommodate TFT displays that aren't quite in the right place. Cut the original panel display hole to suit your display (with a knife) then glue on the bezel. Use this code with a Neopixel LED connected to 5V, 0V and pin 6 (JP4 on the schematic) for data in.https://github.com/CSchlipp/SolderingStation